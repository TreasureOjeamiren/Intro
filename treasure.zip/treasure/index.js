const Name =
    '<h2= First name: Treasure <br>Middle name:Eghelairesho <br> Surname: Ojeamiren <br> Height:5.46ft <br> Country= Nigeria </h2>'

document.write(Name)

